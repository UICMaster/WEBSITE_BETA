window.BlueBottleConfig = {
    // -------------------------------------------------------------
    // DUAL PC SETUP INSTRUCTIONS
    // -------------------------------------------------------------
    // If you are running the League Broadcast Backend on a DIFFERENT 
    // PC than the one capturing the overlay in OBS, change 'localhost'
    // below to the exact IP address of the PC running League Broadcast.
    //
    // Example: host: "192.168.178.30"
    // -------------------------------------------------------------
    host: "localhost",

    // The default port for the League Broadcast Backend is 58869.
    // Do not change this unless you have specifically changed the 
    // port in your backend configuration.
    port: 58869,

    // -------------------------------------------------------------
    // BROADCAST / PATCH OVERRIDES (OPTIONAL)
    // -------------------------------------------------------------
    // Patch information is automatically detected in real-time from
    // the League client (gameVersion) and LeagueBroadcast backend.
    // If you wish to manually override or force a specific patch
    // (e.g. when testing offline or running a replay), set it here:
    // patch: "15.4",
    patch: "",

    // -------------------------------------------------------------
    // SPONSOR CONFIGURATION
    // -------------------------------------------------------------
    // Configure sponsor logos per element. You can use local paths
    // or external web URLs (e.g., "https://example.com/logo.png").
    // If a specific area is left empty (""), it automatically falls
    // back to the 'default' sponsor or bundled default artwork.
    sponsors: {
        default: "",    // Global fallback sponsor
        lframe: "https://ultrainstinctcrew.com/assets/logo/riftops-horizontal-dark.svg",     // L-Frame (Bottom-Left)
        powerplay: "https://ultrainstinctcrew.com/assets/logo/riftops-mark-dark.svg",  // Objective PowerPlays (Right icon)
        sidepanel: "",  // SidePanel Statistics (SideInfo, GoldEfficiency, etc.)
        postgame: "",   // PostGame Analytics Screen
        pregame: "https://ultrainstinctcrew.com/assets/logo/riftops-horizontal-dark.svg",    // Pregame / Champ Select Banner
    }
};
